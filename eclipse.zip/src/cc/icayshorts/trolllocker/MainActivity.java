package cc.icayshorts.trolllocker;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.content.*;
import java.util.*;
import android.view.View.*;
import android.text.*;
import android.view.InputQueue.*;

public class MainActivity extends Activity
{
    @Override
	Intent intent;
	Context context;
	long usedTime=0,newTime=0;
	int keyTouthInt=0;
	TextView tv_time;
	SharedPreferences sp;
	Timer timer;
	TimerTask timertask;
	int theBeginTimeToFinish=1 * 60 * 60 * 24;//Total time, second
	int timetofinish=theBeginTimeToFinish;
    public void onCreate(Bundle savedInstanceState)   
	{
        super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		//Lock the HOME if Android version is 4.0 or higher
		getWindow().setFlags(0x80000000, 0x80000000);
		//You can't set the fullscreen here but in AndroidManifest.xml
        setContentView(R.layout.main);
		context = this;

		//Get widget
		tv_time = (TextView)super.findViewById(R.id.mainTextViewTime);
		
		//start service
		intent = new Intent();
		intent.setClass(MainActivity.this, killpoccessserve.class);
		startService(intent);

		sp = getSharedPreferences("TimeSave", MODE_PRIVATE);
		
		//Get the time that saved
		timetofinish = sp.getInt("saveTime", timetofinish);
		//If countdown smaller than 1 second then reset the timer
		if (timetofinish <= 1)
		{
			timetofinish = theBeginTimeToFinish;
		}
		timer = new Timer();
		
		timertask = new TimerTask(){
			@Override
			public void run()
			{
				runOnUiThread(new Runnable(){

						@Override
						public void run()
						{
							// TODO: Implement this method
							int hour,minute,second;
							hour = timetofinish / (1 * 60 * 60);//Get the hour of lasting
							minute = (timetofinish % (1 * 60 * 60)) / (1 * 60);//Get minute
							second = timetofinish % (1 * 60);//1s
							tv_time.setText(hour + "时" + minute + "分" + second + "秒后清除手机所有数据!");
							sp.edit().putInt("saveTime", timetofinish).commit();//Save the time that can be recover when Locker restarts
							if (timetofinish == 0)//If countdown ends quit the program and nothing happens lol
							{
								stopService(intent);
								System.exit(0);
							}
							timetofinish--;	//小学生被续(-1s)
						}
					});
			}
		};
		timer.schedule(timertask, 0, 1000);//一秒一次
	}

	@Override
	//Listen to the key input
	//There are the FORCE UNLOCK LISTENING in keytouch and onkeydown
	//How to UNLOCK: back*2→Volume down→Volume up→back→home→type any password
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		if (keyCode == event.KEYCODE_BACK)
		{
			if (keyTouthInt == 0)
			{
				usedTime = SystemClock.currentThreadTimeMillis();
				keyTouthInt = 1;
				usedTime = System.currentTimeMillis();
			}
			else if (keyTouthInt == 1)
			{
				keytouch(usedTime, keyTouthInt, 1);
			}
			else
			{
				keytouch(usedTime, keyTouthInt, 4);
			}
		}
		if (keyCode == event.KEYCODE_HOME)
		{
			keytouch(usedTime, keyTouthInt, 5);
			if (keyTouthInt == 6)
			{
				MyDialogFragment f = new MyDialogFragment();
				f.show(getFragmentManager(), "mydialog");
			}
		}
		if (keyCode == event.KEYCODE_MENU)
		{
			keytouch(usedTime, keyTouthInt, 100);
		}
		if (keyCode == event.KEYCODE_VOLUME_DOWN)
		{
			keytouch(usedTime, keyTouthInt, 2);
		}
		if (keyCode == event.KEYCODE_VOLUME_UP)
		{
			keytouch(usedTime, keyTouthInt, 3);
		}
		if (keyCode == event.KEYCODE_POWER)
		{
			Toast.makeText(MainActivity.this, "Toast消息提醒", Toast.LENGTH_SHORT).show();
		}
		return true;
	}

	//Lock the Home button on Android 4.0+, don't worry, 小灰灰是MIUI6以上，都是4.0以上的版本。
    public void onAttachedToWindow()
  	{       
		//this.getWindow().setType(WindowManager.LayoutParams.TYPE_KEYGUARD);   
		super.onAttachedToWindow(); 
	} 

	//Dialog Box
	class MyDialogFragment extends DialogFragment
	{
		@Override
		public Dialog onCreateDialog(Bundle savedInstanceState)
		{
			AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
			final EditText edit=new EditText(context);
			edit.setHint("Hello");
			builder.setView(edit);
			builder.setTitle("输入密码");
			builder.setMessage("解锁请加微信");
			builder.setPositiveButton("解锁", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface p1, int p2)
					{
						String getnumber=edit.getText().toString();
						//if (getnumber.equals("这里是设定的密码"))//If the input is the password then quit
						{
							stopService(intent);
							System.exit(0);
						}	
					}
				});
			builder.setNegativeButton("我是傻逼", new DialogInterface.OnClickListener(){
					@Override
					public void onClick(DialogInterface p1, int p2)
					{
					}
				});
			return builder.create();
		}}

	
	public void keytouch(long useTim, int keyTouthIn, int n)
	{
		newTime = System.currentTimeMillis();
		if ((newTime - useTim) <= 2000 && keyTouthIn == n)
		{
			usedTime = newTime;
			keyTouthInt = keyTouthIn + 1;
		}
		else
		{
			keyTouthInt = 0;
		}
	}
}
	

	





