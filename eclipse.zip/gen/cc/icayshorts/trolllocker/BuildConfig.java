/** Automatically generated file. DO NOT MODIFY */
package cc.icayshorts.trolllocker;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}